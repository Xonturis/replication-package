SELECT id FROM GSPT_Test
WHERE mode = '{mode}';